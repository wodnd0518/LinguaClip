(() => {
  // src/extension/content.ts
  var subtitleHistory = [];
  var lastCaptionText = "";
  function getCurrentSubtitle() {
    return Array.from(document.querySelectorAll(".ytp-caption-segment")).map((el) => el.textContent ?? "").join(" ").trim();
  }
  function getVideo() {
    return document.querySelector("video.html5-main-video");
  }
  function onCaptionChange() {
    const text = getCurrentSubtitle();
    if (!text || text === lastCaptionText) return;
    lastCaptionText = text;
    const time = getVideo()?.currentTime ?? 0;
    subtitleHistory.push({ text, time });
    if (subtitleHistory.length > 60) subtitleHistory.shift();
  }
  function setupCaptionObserver() {
    const player = document.querySelector("#movie_player");
    if (!player) {
      setTimeout(setupCaptionObserver, 1e3);
      return;
    }
    new MutationObserver(onCaptionChange).observe(player, {
      childList: true,
      subtree: true
    });
  }
  setupCaptionObserver();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "YT_GET_INFO") {
      const video = getVideo();
      const videoId = new URLSearchParams(location.search).get("v");
      const titleEl = document.querySelector(
        "ytd-watch-metadata #title h1, h1.ytd-video-primary-info-renderer"
      );
      sendResponse({
        videoId,
        currentTime: video?.currentTime ?? 0,
        duration: video?.duration ?? 0,
        paused: video ? video.paused : true,
        title: titleEl?.textContent?.trim() ?? document.title.replace(" - YouTube", "")
      });
      return true;
    }
    if (message.type === "YT_SEEK") {
      const video = getVideo();
      if (video) {
        video.currentTime = message.seconds;
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false });
      }
      return true;
    }
    if (message.type === "YT_PLAY") {
      const video = getVideo();
      if (video?.paused) video.play();
      sendResponse({ ok: true });
      return true;
    }
    if (message.type === "YT_GET_SUBTITLE") {
      sendResponse({ text: getCurrentSubtitle() });
      return true;
    }
    if (message.type === "YT_CAPTURE_SENTENCE") {
      const video = getVideo();
      const currentTime = video?.currentTime ?? 0;
      const currentText = getCurrentSubtitle();
      if (currentText && currentText !== lastCaptionText) {
        lastCaptionText = currentText;
        subtitleHistory.push({ text: currentText, time: currentTime });
      }
      if (video && !video.paused) video.pause();
      if (subtitleHistory.length === 0) {
        sendResponse({ text: "", startTime: currentTime });
        return true;
      }
      let sentenceStartIdx = 0;
      for (let i = subtitleHistory.length - 2; i >= 0; i--) {
        if (/[.!?]\s*$/.test(subtitleHistory[i].text)) {
          sentenceStartIdx = i + 1;
          break;
        }
      }
      const entries = subtitleHistory.slice(sentenceStartIdx);
      const fullText = entries.map((e) => e.text).join(" ").replace(/\s+/g, " ").trim();
      const startTime = entries[0]?.time ?? currentTime;
      subtitleHistory.length = 0;
      lastCaptionText = "";
      sendResponse({ text: fullText || currentText, startTime });
      return true;
    }
  });
})();
