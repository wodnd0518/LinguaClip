(() => {
  // src/extension/content.ts
  var subtitleHistory = [];
  var lastCaptionText = "";
  function mergeSubtitleChunks(chunks) {
    if (chunks.length === 0) return "";
    let result = chunks[0];
    for (let i = 1; i < chunks.length; i++) {
      const next = chunks[i];
      if (!next) continue;
      const maxOverlap = Math.min(result.length, next.length, 100);
      let overlapLen = 0;
      for (let len = maxOverlap; len >= 4; len--) {
        if (result.slice(-len).toLowerCase() === next.slice(0, len).toLowerCase()) {
          overlapLen = len;
          break;
        }
      }
      result = overlapLen > 0 ? result + next.slice(overlapLen) : result + " " + next;
    }
    return result.replace(/\s+/g, " ").trim();
  }
  function getCurrentSubtitle() {
    return Array.from(document.querySelectorAll(".ytp-caption-segment")).map((el) => el.textContent ?? "").join(" ").trim();
  }
  function getVideo() {
    return document.querySelector("video.html5-main-video");
  }
  function onCaptionChange() {
    const text = getCurrentSubtitle();
    if (!text || text === lastCaptionText) return;
    lastCaptionText = text;
    const time = getVideo()?.currentTime ?? 0;
    subtitleHistory.push({ text, time });
    if (subtitleHistory.length > 60) subtitleHistory.shift();
  }
  function setupCaptionObserver() {
    const player = document.querySelector("#movie_player");
    if (!player) {
      setTimeout(setupCaptionObserver, 1e3);
      return;
    }
    new MutationObserver(onCaptionChange).observe(player, {
      childList: true,
      subtree: true
    });
  }
  setupCaptionObserver();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "YT_GET_INFO") {
      const video = getVideo();
      const videoId = new URLSearchParams(location.search).get("v");
      const titleEl = document.querySelector(
        "ytd-watch-metadata #title h1, h1.ytd-video-primary-info-renderer"
      );
      sendResponse({
        videoId,
        currentTime: video?.currentTime ?? 0,
        duration: video?.duration ?? 0,
        paused: video ? video.paused : true,
        title: titleEl?.textContent?.trim() ?? document.title.replace(" - YouTube", "")
      });
      return true;
    }
    if (message.type === "YT_SEEK") {
      const video = getVideo();
      if (video) {
        video.currentTime = message.seconds;
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false });
      }
      return true;
    }
    if (message.type === "YT_PLAY") {
      const video = getVideo();
      if (video?.paused) video.play();
      sendResponse({ ok: true });
      return true;
    }
    if (message.type === "YT_GET_SUBTITLE") {
      sendResponse({ text: getCurrentSubtitle() });
      return true;
    }
    if (message.type === "YT_CAPTURE_SENTENCE") {
      const video = getVideo();
      const captureTime = video?.currentTime ?? 0;
      const currentText = getCurrentSubtitle();
      if (currentText && currentText !== lastCaptionText) {
        lastCaptionText = currentText;
        subtitleHistory.push({ text: currentText, time: captureTime });
      }
      if (video?.paused) video.play();
      setTimeout(() => {
        const v = getVideo();
        if (v && !v.paused) v.pause();
        const pool = subtitleHistory.filter((e) => e.time >= captureTime - 3);
        const merged = mergeSubtitleChunks(pool.map((e) => e.text));
        const startTime = pool[0]?.time ?? captureTime;
        subtitleHistory.length = 0;
        lastCaptionText = "";
        sendResponse({ text: merged || currentText, startTime });
      }, 1500);
      return true;
    }
  });
})();
