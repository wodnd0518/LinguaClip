(() => {
  // src/extension/content.ts
  function parseJson3(events) {
    return (events ?? []).filter((e) => (e.segs?.length ?? 0) > 0).map((e) => ({
      start: e.tStartMs / 1e3,
      dur: (e.dDurationMs ?? 0) / 1e3,
      text: (e.segs ?? []).map((s) => s.utf8).join("").replace(/\n/g, " ").trim()
    })).filter((l) => l.text);
  }
  async function fetchTranscript(videoId, lang) {
    let tracks = null;
    try {
      const ipr = window.ytInitialPlayerResponse;
      const raw = ipr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
      if (Array.isArray(raw) && raw.length > 0) tracks = raw;
    } catch {
    }
    if (!tracks) {
      const pageRes = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
        headers: { "Accept-Language": "en-US,en;q=0.9" }
      });
      const html = await pageRes.text();
      const tracksMatch = html.match(/"captionTracks":(\[.*?\])/);
      if (!tracksMatch) return { lines: [], languages: [], error: "\uC774 \uC601\uC0C1\uC5D0\uB294 \uC790\uB9C9\uC774 \uC5C6\uC5B4\uC694." };
      tracks = JSON.parse(tracksMatch[1]);
    }
    const track = tracks.find((t) => t.languageCode === lang) ?? tracks.find((t) => t.languageCode.startsWith(lang.split("-")[0])) ?? tracks[0];
    if (!track) return { lines: [], languages: [], error: "\uC790\uB9C9 \uD2B8\uB799\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC5B4\uC694." };
    const captionUrl = track.baseUrl.includes("fmt=") ? track.baseUrl : `${track.baseUrl}&fmt=json3`;
    const captionRes = await fetch(captionUrl);
    if (!captionRes.ok) return { lines: [], languages: [], error: `\uC790\uB9C9 fetch \uC2E4\uD328 (${captionRes.status})` };
    const text = await captionRes.text();
    if (!text.trim()) return { lines: [], languages: [], error: "\uC790\uB9C9 \uC751\uB2F5\uC774 \uBE44\uC5B4\uC788\uC5B4\uC694." };
    const data = JSON.parse(text);
    return {
      lines: parseJson3(data.events),
      languages: tracks.map((t) => ({
        code: t.languageCode,
        name: t.name?.simpleText ?? t.languageCode,
        isAuto: t.kind === "asr"
      })),
      selectedLang: track.languageCode
    };
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "YT_GET_INFO") {
      const video = document.querySelector("video.html5-main-video");
      const videoId = new URLSearchParams(location.search).get("v");
      const titleEl = document.querySelector(
        "ytd-watch-metadata #title h1, h1.ytd-video-primary-info-renderer"
      );
      sendResponse({
        videoId,
        currentTime: video?.currentTime ?? 0,
        duration: video?.duration ?? 0,
        paused: video ? video.paused : true,
        title: titleEl?.textContent?.trim() ?? document.title.replace(" - YouTube", "")
      });
      return true;
    }
    if (message.type === "YT_SEEK") {
      const video = document.querySelector("video.html5-main-video");
      if (video) {
        video.currentTime = message.seconds;
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false });
      }
      return true;
    }
    if (message.type === "YT_GET_TRANSCRIPT") {
      const videoId = message.videoId ?? new URLSearchParams(location.search).get("v") ?? "";
      const lang = message.lang ?? "en";
      if (!videoId) {
        sendResponse({ error: "No video ID", lines: [] });
        return true;
      }
      fetchTranscript(videoId, lang).then(sendResponse).catch((e) => sendResponse({ error: String(e), lines: [] }));
      return true;
    }
  });
})();
