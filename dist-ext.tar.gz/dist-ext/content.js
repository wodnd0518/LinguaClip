(() => {
  // src/extension/content.ts
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "YT_GET_INFO") {
      const video = document.querySelector("video.html5-main-video");
      const videoId = new URLSearchParams(location.search).get("v");
      const titleEl = document.querySelector(
        "ytd-watch-metadata #title h1, h1.ytd-video-primary-info-renderer"
      );
      sendResponse({
        videoId,
        currentTime: video?.currentTime ?? 0,
        duration: video?.duration ?? 0,
        paused: video ? video.paused : true,
        title: titleEl?.textContent?.trim() ?? document.title.replace(" - YouTube", "")
      });
      return true;
    }
    if (message.type === "YT_SEEK") {
      const video = document.querySelector("video.html5-main-video");
      if (video) {
        video.currentTime = message.seconds;
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false });
      }
      return true;
    }
    if (message.type === "YT_GET_SUBTITLE") {
      const segments = document.querySelectorAll(".ytp-caption-segment");
      const text = Array.from(segments).map((el) => el.textContent ?? "").join(" ").trim();
      sendResponse({ text });
      return true;
    }
  });
})();
