(() => {
  // src/extension/background.ts
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id) {
      chrome.sidePanel.open({ tabId: tab.id }).catch(console.error);
    }
  });
})();
