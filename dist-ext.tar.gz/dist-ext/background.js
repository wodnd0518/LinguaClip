(() => {
  // src/extension/background.ts
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id) {
      chrome.sidePanel.open({ tabId: tab.id }).catch(console.error);
    }
  });
  function parseJson3(events) {
    return (events ?? []).filter((e) => (e.segs?.length ?? 0) > 0).map((e) => ({
      start: e.tStartMs / 1e3,
      dur: (e.dDurationMs ?? 0) / 1e3,
      text: (e.segs ?? []).map((s) => s.utf8).join("").replace(/\n/g, " ").trim()
    })).filter((l) => l.text);
  }
  function parseXmlCaptions(xml) {
    const lines = [];
    const re = /<text[^>]+start="([\d.]+)"[^>]*dur="([\d.]+)"[^>]*>([\s\S]*?)<\/text>/g;
    let m;
    while ((m = re.exec(xml)) !== null) {
      const text = m[3].replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#\d+;/g, "").replace(/<[^>]+>/g, "").replace(/\n/g, " ").trim();
      if (text) lines.push({ start: parseFloat(m[1]), dur: parseFloat(m[2]), text });
    }
    return lines;
  }
  function parseGetTranscriptData(data) {
    const lines = [];
    function walk(obj) {
      if (!obj || typeof obj !== "object") return null;
      if ("cueGroups" in obj) return "found";
      for (const v of Object.values(obj)) {
        if (Array.isArray(v)) {
          for (const i of v) {
            if (walk(i)) return "found";
          }
        } else if (walk(v)) return "found";
      }
      return null;
    }
    function extractCues(obj) {
      if (!obj || typeof obj !== "object") return;
      if ("cueGroups" in obj && Array.isArray(obj.cueGroups)) {
        for (const group of obj.cueGroups) {
          const cues = group?.transcriptCueGroupRenderer?.cues ?? [];
          for (const cue of cues) {
            const r = cue?.transcriptCueRenderer;
            if (!r) continue;
            const text = (r.cue?.simpleText ?? // eslint-disable-next-line @typescript-eslint/no-explicit-any
            r.cue?.runs?.map((x) => x.text).join("") ?? "").replace(/\n/g, " ").trim();
            const start = parseInt(r.startOffsetMs, 10);
            const dur = parseInt(r.durationMs, 10);
            if (text && !isNaN(start)) lines.push({ start: start / 1e3, dur: isNaN(dur) ? 3 : dur / 1e3, text });
          }
        }
        return;
      }
      for (const v of Object.values(obj)) {
        if (Array.isArray(v)) {
          for (const i of v) extractCues(i);
        } else extractCues(v);
      }
    }
    if (walk(data)) extractCues(data);
    return lines;
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "YT_GET_TRANSCRIPT") return false;
    const videoId = message.videoId;
    const lang = message.lang ?? "en";
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ error: "YouTube \uD0ED\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC5B4\uC694.", lines: [] });
        return;
      }
      const diag = [];
      try {
        const pageInfo = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: "MAIN",
          args: [lang],
          func: (langCode) => {
            const ytCfg = window.yt?.config_ ?? {};
            const ipr = window.ytInitialPlayerResponse;
            const ytData = window.ytInitialData;
            const rawTracks = ipr?.captions?.playerCaptionsTracklistRenderer?.captionTracks ?? [];
            const tracks = rawTracks.map((t) => ({
              baseUrl: t.baseUrl,
              languageCode: t.languageCode,
              name: t.name,
              kind: t.kind
            }));
            function findTranscriptParams(obj) {
              if (!obj || typeof obj !== "object") return null;
              if ("getTranscriptEndpoint" in obj) return obj.getTranscriptEndpoint?.params ?? null;
              for (const v of Object.values(obj)) {
                const f = Array.isArray(v) ? v.reduce((a, i) => a ?? findTranscriptParams(i), null) : findTranscriptParams(v);
                if (f) return f;
              }
              return null;
            }
            const transcriptParams = findTranscriptParams(ytData);
            const track = tracks.find((t) => t.languageCode === langCode) ?? tracks.find((t) => t.languageCode.startsWith(langCode.split("-")[0])) ?? tracks[0];
            return {
              apiKey: ytCfg.INNERTUBE_API_KEY ?? "",
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              context: ytCfg.INNERTUBE_CONTEXT ?? null,
              visitorData: ytCfg.VISITOR_DATA ?? "",
              transcriptParams: transcriptParams ?? null,
              tracks,
              selectedTrack: track ?? null
            };
          }
        });
        const pi = pageInfo[0]?.result;
        diag.push(`key:${pi?.apiKey ? "ok" : "none"}, ctx:${pi?.context ? "ok" : "none"}, tp:${pi?.transcriptParams ? "ok" : "none"}, tracks:${pi?.tracks?.length ?? 0}`);
        console.log("[LC] pageInfo:", JSON.stringify({ key: !!pi?.apiKey, ctx: !!pi?.context, tp: !!pi?.transcriptParams, tracks: pi?.tracks?.length }));
        let lines = null;
        if (!lines && pi?.apiKey && pi?.context && pi?.transcriptParams) {
          try {
            const apiKey = pi.apiKey;
            const url = `https://www.youtube.com/youtubei/v1/get_transcript?key=${apiKey}&prettyPrint=false`;
            const res = await fetch(url, {
              method: "POST",
              credentials: "include",
              headers: {
                "content-type": "application/json",
                "x-youtube-client-name": String(pi.context?.client?.clientName === "WEB" ? "1" : pi.context?.client?.clientName ?? "1"),
                "x-youtube-client-version": String(pi.context?.client?.clientVersion ?? ""),
                ...pi.visitorData ? { "x-goog-visitor-id": pi.visitorData } : {}
              },
              body: JSON.stringify({
                context: pi.context,
                params: pi.transcriptParams
              })
            });
            const text = res.ok ? await res.text() : "";
            diag.push(`gt_A:${res.status}/${text.length}`);
            console.log("[LC] get_transcript A:", res.status, text.length);
            if (text.trim()) {
              const parsed = parseGetTranscriptData(JSON.parse(text));
              if (parsed.length > 0) lines = parsed;
            }
          } catch (e) {
            diag.push(`gt_A_err:${String(e).slice(0, 20)}`);
            console.log("[LC] gt_A error:", e);
          }
        }
        if (!lines && pi?.apiKey && pi?.context) {
          try {
            const apiKey = pi.apiKey;
            const headers = {
              "content-type": "application/json",
              "x-youtube-client-name": "1",
              "x-youtube-client-version": String(pi.context?.client?.clientVersion ?? "2.20250101.00.00"),
              ...pi.visitorData ? { "x-goog-visitor-id": pi.visitorData } : {}
            };
            const nextRes = await fetch(`https://www.youtube.com/youtubei/v1/next?key=${apiKey}&prettyPrint=false`, {
              method: "POST",
              credentials: "include",
              headers,
              body: JSON.stringify({ videoId, context: pi.context })
            });
            const nextText = nextRes.ok ? await nextRes.text() : "";
            diag.push(`next:${nextRes.status}/${nextText.length}`);
            if (nextText.trim()) {
              let findTp = function(obj) {
                if (!obj || typeof obj !== "object") return null;
                if ("getTranscriptEndpoint" in obj) return obj.getTranscriptEndpoint?.params ?? null;
                for (const v of Object.values(obj)) {
                  const f = Array.isArray(v) ? v.reduce((a, i) => a ?? findTp(i), null) : findTp(v);
                  if (f) return f;
                }
                return null;
              };
              const params = findTp(JSON.parse(nextText));
              diag.push(`tp_B:${params ? "ok" : "none"}`);
              if (params) {
                const gtRes = await fetch(`https://www.youtube.com/youtubei/v1/get_transcript?key=${apiKey}&prettyPrint=false`, {
                  method: "POST",
                  credentials: "include",
                  headers,
                  body: JSON.stringify({ context: pi.context, params })
                });
                const gtText = gtRes.ok ? await gtRes.text() : "";
                diag.push(`gt_B:${gtRes.status}/${gtText.length}`);
                if (gtText.trim()) {
                  const parsed = parseGetTranscriptData(JSON.parse(gtText));
                  if (parsed.length > 0) lines = parsed;
                }
              }
            }
          } catch (e) {
            diag.push(`gt_B_err:${String(e).slice(0, 20)}`);
            console.log("[LC] gt_B error:", e);
          }
        }
        if (!lines && pi?.selectedTrack) {
          const track = pi.selectedTrack;
          const base = `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${encodeURIComponent(track.languageCode)}`;
          const kp = track.kind ? `&kind=${track.kind}` : "";
          const primary = track.baseUrl?.includes("fmt=") ? track.baseUrl : `${track.baseUrl}&fmt=json3`;
          const urls = [
            [primary, true],
            [`${base}${kp}&fmt=json3`, true],
            [`${base}&fmt=json3`, true],
            [`${base}${kp}`, false]
          ];
          for (const [url, isJson3] of urls) {
            try {
              const res = await fetch(url, { credentials: "include" });
              const text = res.ok ? await res.text() : "";
              diag.push(`tt:${res.status}/${text.length}`);
              if (!text.trim()) continue;
              const parsed = isJson3 ? parseJson3(JSON.parse(text).events) : parseXmlCaptions(text);
              if (parsed.length > 0) {
                lines = parsed;
                break;
              }
            } catch {
              continue;
            }
          }
        }
        if (!lines || lines.length === 0) {
          console.log("[LC] all failed:", diag.join(", "));
          sendResponse({ error: `\uC790\uB9C9\uC744 \uBD88\uB7EC\uC62C \uC218 \uC5C6\uC5B4\uC694. [${diag.join(", ")}]`, lines: [] });
          return;
        }
        const allTracks = pi?.tracks ?? [];
        const languages = allTracks.map((t) => ({
          code: t.languageCode,
          name: t.name?.simpleText ?? t.languageCode,
          isAuto: t.kind === "asr"
        }));
        const selectedLang = pi?.selectedTrack?.languageCode ?? lang;
        console.log("[LC] success:", lines.length, "lines", diag.join(", "));
        sendResponse({ lines, languages: languages.length > 0 ? languages : [{ code: lang, name: lang, isAuto: false }], selectedLang });
      } catch (e) {
        console.log("[LC] fatal error:", e, diag.join(", "));
        sendResponse({ error: `\uC624\uB958: ${String(e)} [${diag.join(", ")}]`, lines: [] });
      }
    });
    return true;
  });
})();
