(() => {
  // src/extension/background.ts
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id) {
      chrome.sidePanel.open({ tabId: tab.id }).catch(console.error);
    }
  });
  function parseJson3(events) {
    return (events ?? []).filter((e) => (e.segs?.length ?? 0) > 0).map((e) => ({
      start: e.tStartMs / 1e3,
      dur: (e.dDurationMs ?? 0) / 1e3,
      text: (e.segs ?? []).map((s) => s.utf8).join("").replace(/\n/g, " ").trim()
    })).filter((l) => l.text);
  }
  function parseXmlCaptions(xml) {
    const lines = [];
    const re = /<text[^>]+start="([\d.]+)"[^>]*dur="([\d.]+)"[^>]*>([\s\S]*?)<\/text>/g;
    let m;
    while ((m = re.exec(xml)) !== null) {
      const text = m[3].replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#\d+;/g, "").replace(/<[^>]+>/g, "").replace(/\n/g, " ").trim();
      if (text) lines.push({ start: parseFloat(m[1]), dur: parseFloat(m[2]), text });
    }
    return lines;
  }
  function findKey(obj, key) {
    if (!obj || typeof obj !== "object") return null;
    const o = obj;
    if (key in o) return o[key];
    for (const v of Object.values(o)) {
      const found = findKey(Array.isArray(v) ? { _: v } : v, key);
      if (found !== null) return found;
      if (Array.isArray(v)) {
        for (const item of v) {
          const f = findKey(item, key);
          if (f !== null) return f;
        }
      }
    }
    return null;
  }
  async function getTracksViaAndroid(videoId) {
    try {
      const res = await fetch("https://www.youtube.com/youtubei/v1/player", {
        method: "POST",
        credentials: "include",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          videoId,
          context: {
            client: { clientName: "ANDROID", clientVersion: "20.10.38", androidSdkVersion: 30 }
          }
        })
      });
      if (!res.ok) {
        console.log("[LC] ANDROID player", res.status);
        return null;
      }
      const data = await res.json();
      const raw = data?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
      if (!Array.isArray(raw) || raw.length === 0) {
        console.log("[LC] ANDROID: no tracks");
        return null;
      }
      console.log("[LC] ANDROID: tracks", raw.length, raw.map((t) => `${t.languageCode}/${t.kind}`));
      return raw;
    } catch (e) {
      console.log("[LC] ANDROID error:", e);
      return null;
    }
  }
  async function getTranscriptViaInnerTube(videoId, lang) {
    try {
      const CLIENT = { clientName: "WEB", clientVersion: "2.20250101.00.00", hl: lang, gl: "US" };
      const headers = {
        "content-type": "application/json",
        "x-youtube-client-name": "1",
        "x-youtube-client-version": CLIENT.clientVersion
      };
      const nextRes = await fetch("https://www.youtube.com/youtubei/v1/next", {
        method: "POST",
        credentials: "include",
        headers,
        body: JSON.stringify({ videoId, context: { client: CLIENT } })
      });
      if (!nextRes.ok) {
        console.log("[LC] /next", nextRes.status);
        return null;
      }
      const nextData = await nextRes.json();
      const params = findKey(nextData, "getTranscriptEndpoint");
      const paramsStr = params?.params;
      if (!paramsStr) {
        console.log("[LC] get_transcript: params not found");
        return null;
      }
      const tRes = await fetch("https://www.youtube.com/youtubei/v1/get_transcript", {
        method: "POST",
        credentials: "include",
        headers,
        body: JSON.stringify({ context: { client: { clientName: "WEB", clientVersion: CLIENT.clientVersion } }, params: paramsStr })
      });
      if (!tRes.ok) {
        console.log("[LC] get_transcript", tRes.status);
        return null;
      }
      const tData = await tRes.json();
      const cueGroups = findKey(tData, "cueGroups");
      if (!Array.isArray(cueGroups) || cueGroups.length === 0) {
        console.log("[LC] get_transcript: no cueGroups");
        return null;
      }
      const lines = [];
      for (const group of cueGroups) {
        const cues = group?.transcriptCueGroupRenderer?.cues ?? [];
        for (const cue of cues) {
          const r = cue?.transcriptCueRenderer;
          if (!r) continue;
          const text = (r.cue?.simpleText ?? r.cue?.runs?.map((x) => x.text).join("") ?? "").replace(/\n/g, " ").trim();
          const start = parseInt(r.startOffsetMs, 10);
          const dur = parseInt(r.durationMs, 10);
          if (text && !isNaN(start) && !isNaN(dur)) lines.push({ start: start / 1e3, dur: dur / 1e3, text });
        }
      }
      console.log("[LC] get_transcript: lines", lines.length);
      return lines.length > 0 ? lines : null;
    } catch (e) {
      console.log("[LC] get_transcript error:", e);
      return null;
    }
  }
  function selectTrack(tracks, lang) {
    return tracks.find((t) => t.languageCode === lang) ?? tracks.find((t) => t.languageCode.startsWith(lang.split("-")[0])) ?? tracks[0];
  }
  async function fetchCaptionText(url) {
    try {
      const res = await fetch(url, { credentials: "include" });
      const text = res.ok ? await res.text() : "";
      console.log(`[LC] caption fetch ${res.status} len=${text.length}`, url.replace(/^https:\/\/[^?]+\?/, "").slice(0, 60));
      return text;
    } catch (e) {
      console.log("[LC] caption fetch error:", e);
      return "";
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "YT_GET_TRANSCRIPT") return false;
    const videoId = message.videoId;
    const lang = message.lang ?? "en";
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ error: "YouTube \uD0ED\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC5B4\uC694.", lines: [] });
        return;
      }
      const diag = [];
      try {
        let lines = null;
        let allTracks = null;
        const androidTracks = await getTracksViaAndroid(videoId);
        diag.push(`android:${androidTracks?.length ?? 0}\uD2B8\uB799`);
        if (androidTracks && androidTracks.length > 0) {
          allTracks = androidTracks;
          const track = selectTrack(androidTracks, lang);
          const base = `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${encodeURIComponent(track.languageCode)}`;
          const kindParam = track.kind ? `&kind=${track.kind}` : "";
          const primaryUrl = track.baseUrl.includes("fmt=") ? track.baseUrl : `${track.baseUrl}&fmt=json3`;
          const urlsToTry = [
            [primaryUrl, true],
            [`${base}${kindParam}&fmt=json3`, true],
            [`${base}&fmt=json3`, true],
            [`${base}${kindParam}`, false]
          ];
          for (const [url, isJson3] of urlsToTry) {
            const text = await fetchCaptionText(url);
            diag.push(`${isJson3 ? "j3" : "xml"}:${text.length}`);
            if (!text.trim()) continue;
            try {
              const parsed = isJson3 ? parseJson3(JSON.parse(text).events) : parseXmlCaptions(text);
              if (parsed.length > 0) {
                lines = parsed;
                break;
              }
            } catch {
              continue;
            }
          }
        }
        if (!lines || lines.length === 0) {
          diag.push("\u2192get_transcript");
          const gtLines = await getTranscriptViaInnerTube(videoId, lang);
          diag.push(`gt:${gtLines?.length ?? 0}`);
          if (gtLines && gtLines.length > 0) lines = gtLines;
        }
        if (!lines || lines.length === 0) {
          diag.push("\u2192ipr");
          try {
            const scriptResult = await chrome.scripting.executeScript({
              target: { tabId: tab.id },
              world: "MAIN",
              args: [videoId, lang],
              func: async (vid, lc) => {
                try {
                  const ipr = window.ytInitialPlayerResponse;
                  const raw = ipr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
                  if (!Array.isArray(raw) || raw.length === 0) return { lines: null, error: "no tracks" };
                  const track = raw.find((t) => t.languageCode === lc) ?? raw.find((t) => t.languageCode.startsWith(lc.split("-")[0])) ?? raw[0];
                  const url = track.baseUrl.includes("fmt=") ? track.baseUrl : `${track.baseUrl}&fmt=json3`;
                  const res = await fetch(url);
                  const text = await res.text();
                  return { lines: null, rawText: text, langCode: track.languageCode, kind: track.kind, videoIdMatch: ipr?.videoDetails?.videoId === vid };
                } catch (e) {
                  return { lines: null, error: String(e) };
                }
              }
            });
            const r = scriptResult[0]?.result;
            diag.push(`ipr_raw:${r?.rawText?.length ?? 0}`);
            if (r?.rawText?.trim()) {
              try {
                lines = parseJson3(JSON.parse(r.rawText).events);
              } catch {
                lines = parseXmlCaptions(r.rawText);
              }
            }
          } catch (e) {
            diag.push(`ipr_err:${String(e).slice(0, 20)}`);
          }
        }
        if (!lines || lines.length === 0) {
          sendResponse({ error: `\uC790\uB9C9\uC744 \uBD88\uB7EC\uC62C \uC218 \uC5C6\uC5B4\uC694. [${diag.join(", ")}]`, lines: [] });
          return;
        }
        const languages = (allTracks ?? []).map((t) => ({
          code: t.languageCode,
          name: t.name?.simpleText ?? t.languageCode,
          isAuto: t.kind === "asr"
        }));
        const selectedLang = allTracks ? selectTrack(allTracks, lang).languageCode : lang;
        sendResponse({ lines, languages, selectedLang });
      } catch (e) {
        sendResponse({ error: `\uC624\uB958: ${String(e)} [${diag.join(", ")}]`, lines: [] });
      }
    });
    return true;
  });
})();
