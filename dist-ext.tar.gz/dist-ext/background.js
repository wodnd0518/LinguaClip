(() => {
  // src/extension/background.ts
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id) {
      chrome.sidePanel.open({ tabId: tab.id }).catch(console.error);
    }
  });
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "YT_GET_TRANSCRIPT") return false;
    const videoId = message.videoId;
    const lang = message.lang ?? "en";
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ error: "YouTube \uD0ED\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC5B4\uC694.", lines: [] });
        return;
      }
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: "MAIN",
          // YouTube 페이지 JS context에서 실행 (쿠키 포함)
          args: [videoId, lang],
          func: async (vid, langCode) => {
            function parseJson3(events2) {
              return (events2 ?? []).filter((e) => (e.segs?.length ?? 0) > 0).map((e) => ({
                start: e.tStartMs / 1e3,
                dur: (e.dDurationMs ?? 0) / 1e3,
                text: (e.segs ?? []).map((s) => s.utf8).join("").replace(/\n/g, " ").trim()
              })).filter((l) => l.text);
            }
            let tracks = null;
            try {
              const ipr = window.ytInitialPlayerResponse;
              const raw = ipr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
              if (Array.isArray(raw) && raw.length > 0) tracks = raw;
              console.log("[LC] ytInitialPlayerResponse tracks:", tracks?.length ?? 0);
            } catch {
            }
            if (!tracks) {
              try {
                const listRes = await fetch(
                  `https://www.youtube.com/api/timedtext?v=${vid}&type=list`,
                  { headers: { "Accept-Language": "en-US,en;q=0.9" } }
                );
                if (listRes.ok) {
                  const xml = await listRes.text();
                  const xmlDoc = new DOMParser().parseFromString(xml, "text/xml");
                  const trackEls = Array.from(xmlDoc.querySelectorAll("track"));
                  if (trackEls.length > 0) {
                    tracks = trackEls.map((el) => {
                      const langCode2 = el.getAttribute("lang_code") ?? "";
                      const name = el.getAttribute("name") ?? "";
                      const langOriginal = el.getAttribute("lang_original") ?? langCode2;
                      const kind = el.getAttribute("kind") ?? void 0;
                      const baseUrl = `https://www.youtube.com/api/timedtext?v=${vid}&lang=${encodeURIComponent(langCode2)}` + (kind ? `&kind=${kind}` : "") + (name ? `&name=${encodeURIComponent(name)}` : "") + `&fmt=json3`;
                      return { baseUrl, languageCode: langCode2, name: { simpleText: langOriginal }, kind };
                    });
                  }
                }
              } catch {
              }
            }
            if (!tracks) return { lines: [], languages: [], error: "\uC774 \uC601\uC0C1\uC5D0\uB294 \uC790\uB9C9\uC774 \uC5C6\uC5B4\uC694." };
            const track = tracks.find((t) => t.languageCode === langCode) ?? tracks.find((t) => t.languageCode.startsWith(langCode.split("-")[0])) ?? tracks[0];
            if (!track) return { lines: [], languages: [], error: "\uC790\uB9C9 \uD2B8\uB799\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC5B4\uC694." };
            async function fetchRaw(url) {
              try {
                const res = await fetch(url);
                const text2 = res.ok ? await res.text() : "";
                console.log(`[LC] fetch ${res.status} len=${text2.length}`, url.split("?")[1]);
                return text2;
              } catch (e) {
                console.log("[LC] fetch error:", e, url.split("?")[1]);
                return "";
              }
            }
            function parseXml(xml) {
              const doc = new DOMParser().parseFromString(xml, "text/xml");
              return Array.from(doc.querySelectorAll("text")).map((el) => ({
                tStartMs: parseFloat(el.getAttribute("start") ?? "0") * 1e3,
                dDurationMs: parseFloat(el.getAttribute("dur") ?? "0") * 1e3,
                segs: [{ utf8: el.textContent ?? "" }]
              }));
            }
            const captionUrl = track.baseUrl.includes("fmt=") ? track.baseUrl : `${track.baseUrl}&fmt=json3`;
            const base = `https://www.youtube.com/api/timedtext?v=${vid}&lang=${encodeURIComponent(track.languageCode)}`;
            const kindParam = track.kind ? `&kind=${track.kind}` : "";
            console.log("[LC] selected track:", track.languageCode, track.kind);
            const json3Urls = [
              captionUrl,
              `${base}${kindParam}&fmt=json3`,
              `${base}&fmt=json3`
            ];
            const xmlUrls = [
              `${base}${kindParam}`,
              `${base}`
            ];
            let text = "";
            let isXml = false;
            for (const url of json3Urls) {
              text = await fetchRaw(url);
              if (text.trim()) break;
            }
            if (!text.trim()) {
              for (const url of xmlUrls) {
                text = await fetchRaw(url);
                if (text.trim()) {
                  isXml = true;
                  break;
                }
              }
            }
            if (!text.trim()) return { lines: [], languages: [], error: "\uC790\uB9C9\uC744 \uBD88\uB7EC\uC62C \uC218 \uC5C6\uC5B4\uC694. \uC774 \uC601\uC0C1\uC5D0\uB294 \uC790\uB9C9\uC774 \uC5C6\uAC70\uB098 \uC811\uADFC\uC774 \uC81C\uD55C\uB418\uC5B4 \uC788\uC5B4\uC694." };
            const events = isXml ? parseXml(text) : JSON.parse(text).events;
            return {
              lines: parseJson3(events),
              languages: tracks.map((t) => ({
                code: t.languageCode,
                name: t.name?.simpleText ?? t.languageCode,
                isAuto: t.kind === "asr"
              })),
              selectedLang: track.languageCode
            };
          }
        });
        const result = results[0]?.result;
        if (!result) {
          sendResponse({ error: "\uC2A4\uD06C\uB9BD\uD2B8 \uC2E4\uD589 \uACB0\uACFC\uAC00 \uC5C6\uC5B4\uC694.", lines: [] });
        } else {
          sendResponse(result);
        }
      } catch (e) {
        sendResponse({ error: String(e), lines: [] });
      }
    });
    return true;
  });
})();
