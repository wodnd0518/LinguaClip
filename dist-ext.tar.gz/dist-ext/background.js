(() => {
  // src/extension/background.ts
  chrome.action.onClicked.addListener((tab) => {
    if (tab.id) {
      chrome.sidePanel.open({ tabId: tab.id }).catch(console.error);
    }
  });
  function parseJson3(events) {
    return (events ?? []).filter((e) => (e.segs?.length ?? 0) > 0).map((e) => ({
      start: e.tStartMs / 1e3,
      dur: (e.dDurationMs ?? 0) / 1e3,
      text: (e.segs ?? []).map((s) => s.utf8).join("").replace(/\n/g, " ").trim()
    })).filter((l) => l.text);
  }
  function parseXmlCaptions(xml) {
    const lines = [];
    const re = /<text[^>]+start="([\d.]+)"[^>]*dur="([\d.]+)"[^>]*>([\s\S]*?)<\/text>/g;
    let m;
    while ((m = re.exec(xml)) !== null) {
      const text = m[3].replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#\d+;/g, "").replace(/<[^>]+>/g, "").replace(/\n/g, " ").trim();
      if (text) lines.push({ start: parseFloat(m[1]), dur: parseFloat(m[2]), text });
    }
    return lines;
  }
  async function bgFetch(url) {
    try {
      const res = await fetch(url, { credentials: "include" });
      const text = res.ok ? await res.text() : "";
      console.log(`[LC BG] ${res.status} len=${text.length}`, url.replace("https://www.youtube.com/api/timedtext?", "").slice(0, 80));
      return { text, status: res.status };
    } catch (e) {
      console.log("[LC BG] fetch exception:", String(e));
      return { text: "", status: 0 };
    }
  }
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type !== "YT_GET_TRANSCRIPT") return false;
    const videoId = message.videoId;
    const lang = message.lang ?? "en";
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ error: "YouTube \uD0ED\uC744 \uCC3E\uC744 \uC218 \uC5C6\uC5B4\uC694.", lines: [] });
        return;
      }
      const diagnostics = [];
      try {
        const scriptResult = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          world: "MAIN",
          args: [videoId],
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          func: (_vid) => {
            try {
              const ipr = window.ytInitialPlayerResponse;
              const raw = ipr?.captions?.playerCaptionsTracklistRenderer?.captionTracks;
              if (Array.isArray(raw) && raw.length > 0) {
                return { tracks: raw.map((t) => ({
                  baseUrl: t.baseUrl,
                  languageCode: t.languageCode,
                  name: t.name,
                  kind: t.kind
                })), source: "ipr" };
              }
            } catch {
            }
            return { tracks: null, source: "none" };
          }
        });
        const iprData = scriptResult[0]?.result;
        let tracks = iprData?.tracks ?? null;
        diagnostics.push(`ipr:${tracks?.length ?? 0}\uD2B8\uB799`);
        if (!tracks) {
          const { text: listXml, status } = await bgFetch(
            `https://www.youtube.com/api/timedtext?v=${videoId}&type=list`
          );
          diagnostics.push(`list:${status}/${listXml.length}`);
          if (listXml.trim()) {
            const parsed = [];
            const re = /<track\b([^>]*)>/g;
            let m;
            while ((m = re.exec(listXml)) !== null) {
              const attr = (name2) => m[1].match(new RegExp(`${name2}="([^"]*)"`))?.[1] ?? "";
              const langCode = attr("lang_code");
              if (!langCode) continue;
              const kind = attr("kind") || void 0;
              const name = attr("name");
              const langOriginal = attr("lang_original") || langCode;
              const baseUrl = `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${encodeURIComponent(langCode)}` + (kind ? `&kind=${kind}` : "") + (name ? `&name=${encodeURIComponent(name)}` : "");
              parsed.push({ baseUrl, languageCode: langCode, name: { simpleText: langOriginal }, kind });
            }
            if (parsed.length > 0) tracks = parsed;
            diagnostics.push(`parsed:${tracks?.length ?? 0}\uD2B8\uB799`);
          }
        }
        if (!tracks || tracks.length === 0) {
          sendResponse({ error: `\uC790\uB9C9 \uC5C6\uC74C [${diagnostics.join(", ")}]`, lines: [] });
          return;
        }
        const track = tracks.find((t) => t.languageCode === lang) ?? tracks.find((t) => t.languageCode.startsWith(lang.split("-")[0])) ?? tracks[0];
        const base = `https://www.youtube.com/api/timedtext?v=${videoId}&lang=${encodeURIComponent(track.languageCode)}`;
        const kindParam = track.kind ? `&kind=${track.kind}` : "";
        const primaryUrl = track.baseUrl.includes("fmt=") ? track.baseUrl : `${track.baseUrl}&fmt=json3`;
        const urlsToTry = [
          [primaryUrl, true],
          [`${base}${kindParam}&fmt=json3`, true],
          [`${base}&fmt=json3`, true],
          [`${base}${kindParam}`, false],
          [`${base}`, false]
        ];
        let lines = null;
        for (const [url, isJson3] of urlsToTry) {
          const { text, status } = await bgFetch(url);
          diagnostics.push(`${isJson3 ? "j3" : "xml"}:${status}/${text.length}`);
          if (!text.trim()) continue;
          try {
            lines = isJson3 ? parseJson3(JSON.parse(text).events) : parseXmlCaptions(text);
            if (lines.length > 0) {
              console.log("[LC BG] \u2713 success, lines:", lines.length);
              break;
            }
          } catch (e) {
            diagnostics.push(`parse_err:${String(e).slice(0, 30)}`);
          }
        }
        if (!lines || lines.length === 0) {
          sendResponse({
            error: `\uC790\uB9C9\uC744 \uBD88\uB7EC\uC62C \uC218 \uC5C6\uC5B4\uC694. [${diagnostics.join(", ")}]`,
            lines: []
          });
          return;
        }
        sendResponse({
          lines,
          languages: tracks.map((t) => ({
            code: t.languageCode,
            name: t.name?.simpleText ?? t.languageCode,
            isAuto: t.kind === "asr"
          })),
          selectedLang: track.languageCode
        });
      } catch (e) {
        sendResponse({ error: `\uC624\uB958: ${String(e)} [${diagnostics.join(", ")}]`, lines: [] });
      }
    });
    return true;
  });
})();
